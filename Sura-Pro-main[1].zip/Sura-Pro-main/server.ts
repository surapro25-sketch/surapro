import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '20mb' }));

// Initialise Gemini client with required User-Agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

function extractErrorMessage(err: any): string {
  if (!err) return 'An unexpected error occurred.';
  const msg = err.message || String(err);
  try {
    const parsed = JSON.parse(msg);
    if (parsed?.error?.message) {
      return parsed.error.message;
    }
  } catch (_) {}
  return msg;
}

/**
 * Convert 16-bit PCM buffer to standard RIFF/WAVE buffer
 */
function pcmToWav(
  pcmBuffer: Buffer,
  sampleRate = 24000,
  numChannels = 1,
  bitsPerSample = 16
): Buffer {
  const byteRate = sampleRate * numChannels * (bitsPerSample / 8);
  const blockAlign = numChannels * (bitsPerSample / 8);
  const dataSize = pcmBuffer.length;
  const header = Buffer.alloc(44);

  header.write('RIFF', 0);
  header.writeUInt32LE(dataSize + 36, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20); // 1 = PCM format
  header.writeUInt16LE(numChannels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bitsPerSample, 34);
  header.write('data', 36);
  header.writeUInt32LE(dataSize, 40);

  return Buffer.concat([header, pcmBuffer]);
}

/**
 * Endpoint: /api/tts/generate
 * Generates speech using gemini-3.8-flash-tts
 * Supports single-speaker or dual-speaker dialogue mode.
 */
app.post('/api/tts/generate', async (req: Request, res: Response) => {
  try {
    const {
      mode = 'single', // 'single' | 'dialogue'
      text,
      voice = 'Kore',
      style,
      dialogueLines, // Array of { speaker: string, text: string, voice: string, style?: string }
      speaker1Config, // { name: string, voice: string, style?: string }
      speaker2Config, // { name: string, voice: string, style?: string }
    } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      res.status(500).json({
        error: 'GEMINI_API_KEY is not configured on the server. Please check your environment variables.',
      });
      return;
    }

    let response;

    if (mode === 'dialogue' && Array.isArray(dialogueLines) && dialogueLines.length > 0) {
      // Dual-speaker mode
      const s1 = speaker1Config || { name: 'Speaker 1', voice: 'Kore' };
      const s2 = speaker2Config || { name: 'Speaker 2', voice: 'Puck' };

      const parts = dialogueLines.map((line: { speaker: string; text: string; style?: string }) => ({
        text: `${line.speaker}: ${line.text}`,
        speechMetadata: {
          speaker: line.speaker,
          style: line.style || 'Natural, expressive conversational tone',
        },
      }));

      response = await ai.models.generateContent({
        model: 'gemini-3.8-flash-tts',
        contents: [
          {
            role: 'user',
            parts,
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            multiSpeakerVoiceConfig: {
              speakerVoiceConfigs: [
                {
                  speaker: s1.name,
                  voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: s1.voice || 'Kore' },
                  },
                },
                {
                  speaker: s2.name,
                  voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: s2.voice || 'Puck' },
                  },
                },
              ],
            },
          },
        },
      });
    } else {
      // Single-speaker mode
      if (!text || typeof text !== 'string' || text.trim().length === 0) {
        res.status(400).json({ error: 'Text prompt is required.' });
        return;
      }

      response = await ai.models.generateContent({
        model: 'gemini-3.8-flash-tts',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: text.trim(),
                speechMetadata: {
                  style: style || 'Clear, natural, warm, and authentic pronunciation',
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voice || 'Kore' },
            },
          },
        },
      });
    }

    const candidate = response.candidates?.[0];
    const audioPart = candidate?.content?.parts?.find(
      (part: any) => part.inlineData && part.inlineData.data
    );

    if (!audioPart || !audioPart.inlineData?.data) {
      res.status(500).json({
        error: 'No audio stream returned from Gemini TTS. Please verify the text input and try again.',
      });
      return;
    }

    const rawBase64 = audioPart.inlineData.data;
    const mimeType = audioPart.inlineData.mimeType || 'audio/pcm;rate=24000';
    let wavBase64 = rawBase64;
    let sampleRate = 24000;

    // If mimeType is PCM, wrap it into standard WAV container
    if (mimeType.includes('pcm') || mimeType.includes('raw') || !mimeType.includes('wav')) {
      const pcmBuffer = Buffer.from(rawBase64, 'base64');
      const wavBuffer = pcmToWav(pcmBuffer, sampleRate, 1, 16);
      wavBase64 = wavBuffer.toString('base64');
    }

    // Estimate duration: 24000 samples/sec, 16-bit (2 bytes per sample), mono
    const pcmByteLength = Buffer.from(rawBase64, 'base64').length;
    const durationSeconds = pcmByteLength / (sampleRate * 2);

    res.json({
      audioBase64: wavBase64,
      mimeType: 'audio/wav',
      sampleRate,
      durationSeconds: Number(durationSeconds.toFixed(2)),
      model: 'gemini-3.8-flash-tts',
    });
  } catch (err: any) {
    console.error('Error generating TTS:', err);
    res.status(500).json({
      error: extractErrorMessage(err) || 'Failed to generate speech with gemini-3.8-flash-tts.',
    });
  }
});

/**
 * Endpoint: /api/ai/script-assist
 * Uses gemini-3.8-flash for generating scripts, Amharic translations,
 * adding expressive markers, or polishing text for speech synthesis.
 */
app.post('/api/ai/script-assist', async (req: Request, res: Response) => {
  try {
    const { action, prompt, currentText, targetLanguage } = req.body;

    if (!process.env.GEMINI_API_KEY) {
      res.status(500).json({
        error: 'GEMINI_API_KEY is not configured on the server.',
      });
      return;
    }

    let systemInstruction = `You are an expert multilingual speechwriter and linguist specializing in Ethiopian languages (Amharic, Tigrinya, Afaan Oromoo) and English speech.
You craft natural, spoken-word texts with emotional authenticity, proper Ge'ez punctuation (፣ for comma, ። for period, ፤ for semicolon), and speech pauses.
When requested, you can suggest expressive speech tags supported by Gemini TTS: <breath>, <laugh>, <gasp>, |yeah|, |mhm|.
Only output the script text itself without conversational filler or disclaimers so it can immediately be read by Text-to-Speech.`;

    let userPrompt = '';
    if (action === 'generate') {
      userPrompt = `Write a compelling spoken speech script for TTS based on this prompt: "${prompt}".
Language preference: ${targetLanguage || 'Amharic (አማርኛ) or bilingual'}.
Include proper speech cadence and natural phrasing.`;
    } else if (action === 'translate') {
      userPrompt = `Translate and adapt the following text to natural, spoken ${targetLanguage || 'Amharic (አማርኛ)'} optimized for audio text-to-speech reading:
"""
${currentText}
"""`;
    } else if (action === 'add_bursts') {
      userPrompt = `Enhance the following script by inserting realistic vocal burst tags (<breath>, <laugh>, <gasp>, |yeah|, |mhm|) where natural in spoken dialogue:
"""
${currentText}
"""`;
    } else if (action === 'dialogue') {
      userPrompt = `Create a 4-line natural dialogue between two speakers (e.g. Almaz and Bekele) on this topic: "${prompt}".
Format strictly as lines starting with speaker names, for example:
Almaz: ሰላም በቀለ! እንዴት ነህ?
Bekele: ሰላም አልማዝ! ደህና ነኝ አመሰግናለሁ።
Include natural emotional expressions.`;
    } else {
      userPrompt = `Polish and improve the rhythm of this speech text for audio synthesis:
"""
${currentText}
"""`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const resultText = response.text || '';
    res.json({ result: resultText.trim() });
  } catch (err: any) {
    console.error('Error in script assist:', err);
    res.status(500).json({
      error: extractErrorMessage(err) || 'Failed to assist with script generation.',
    });
  }
});

// Setup Vite in development or serve static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer();
