export type StudioMode = 'single' | 'dialogue';

export type VoiceName = 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';

export interface VoiceOption {
  id: VoiceName;
  name: string;
  amharicName: string;
  gender: 'Female' | 'Male' | 'Neutral';
  description: string;
  amharicDesc: string;
  tags: string[];
}

export interface DialogueLine {
  id: string;
  speaker: string;
  text: string;
  style?: string;
}

export interface SpeakerConfig {
  name: string;
  voice: VoiceName;
  style: string;
}

export interface GeneratedAudioItem {
  id: string;
  title: string;
  text: string;
  mode: StudioMode;
  voice: string;
  audioBase64: string;
  durationSeconds: number;
  createdAt: number;
  model: string;
}

export interface PresetScript {
  id: string;
  titleEn: string;
  titleAm: string;
  category: 'greeting' | 'culture' | 'wisdom' | 'dialogue' | 'history' | 'english';
  mode: StudioMode;
  text?: string;
  voice?: VoiceName;
  style?: string;
  speaker1?: SpeakerConfig;
  speaker2?: SpeakerConfig;
  dialogueLines?: DialogueLine[];
  description: string;
}
