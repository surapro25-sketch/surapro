/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Mic,
  Volume2,
  Users,
  Sparkles,
  History,
  Languages,
  BookOpen,
  Info,
  AlertCircle,
  Radio,
  CheckCircle2,
} from 'lucide-react';
import { SingleSpeakerStudio } from './components/SingleSpeakerStudio';
import { DualSpeakerStudio } from './components/DualSpeakerStudio';
import { PresetsSection } from './components/PresetsSection';
import { HistorySection } from './components/HistorySection';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { ScriptAssistantModal } from './components/ScriptAssistantModal';
import { PRESET_SCRIPTS } from './constants/presets';
import {
  VoiceName,
  DialogueLine,
  SpeakerConfig,
  GeneratedAudioItem,
  PresetScript,
} from './types';

const INITIAL_TEXT =
  'ሰላም ሰላም እንኳን ደህና መጡ! ወደ ድምጽ ስቱዲዮ እንኳን በደህና መጡ። <breath> እዚህ ጽሑፍዎን ወደ ሕያው፣ ጥርት ያለ እና አስደናቂ የተፈጥሮ ድምፅ መለወጥ ይችላሉ።';

const DEFAULT_STYLE =
  'Warm, authentic Ethiopian storyteller with natural pronunciation, gentle cadence, and emotional warmth';

export default function App() {
  const [language, setLanguage] = useState<'en' | 'am'>('am');
  const [activeTab, setActiveTab] = useState<'solo' | 'dialogue' | 'presets' | 'history'>('solo');

  // Solo Studio State
  const [text, setText] = useState<string>(INITIAL_TEXT);
  const [voice, setVoice] = useState<VoiceName>('Kore');
  const [style, setStyle] = useState<string>(DEFAULT_STYLE);

  // Dual Speaker State
  const [speaker1, setSpeaker1] = useState<SpeakerConfig>({
    name: 'Almaz',
    voice: 'Kore',
    style: 'Enthusiastic, bright tech podcast host',
  });
  const [speaker2, setSpeaker2] = useState<SpeakerConfig>({
    name: 'Bekele',
    voice: 'Fenrir',
    style: 'Curious, thoughtful conversationalist',
  });
  const [dialogueLines, setDialogueLines] = useState<DialogueLine[]>([
    {
      id: '1',
      speaker: 'Almaz',
      text: 'ሰላም በቀለ! <breath> በቅርቡ የተለቀቀውን አዲሱን የሰው ሠራሽ አስተውሎት የድምፅ ቴክኖሎጂ ሞከርከው?',
      style: 'Enthusiastic greeting with bright curiosity',
    },
    {
      id: '2',
      speaker: 'Bekele',
      text: 'አዎ አልማዝ፣ |yeah| በጣም የሚገርም ነው! <laugh> አማርኛን ሳይቀር ልክ እንደ አገሬው ሰው አጥርቶ ይናገራል።',
      style: 'Amazed and laughing warmly',
    },
    {
      id: '3',
      speaker: 'Almaz',
      text: 'በትክክል! <breath> አሁን የትምህርት፣ የመጽሐፍት እና የፊልም ድምፆችን በከፍተኛ ጥራት ማዘጋጀት ተችሏል።',
      style: 'Passionate and articulate explanation',
    },
    {
      id: '4',
      speaker: 'Bekele',
      text: 'እውነትሽን ነው፣ |mhm| ይህ ለሀገራችን የዲጂታል እድገት ትልቅ እርምጃ ነው።',
      style: 'Reflective and nodding agreement',
    },
  ]);

  // Generation & Audio State
  const [isLoading, setIsLoading] = useState(false);
  const [currentTrack, setCurrentTrack] = useState<GeneratedAudioItem | null>(null);
  const [history, setHistory] = useState<GeneratedAudioItem[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Modal State
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);

  // Load history from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('dimts_audio_history');
      if (saved) {
        setHistory(JSON.parse(saved));
      }
    } catch (e) {
      console.error('Failed to load history:', e);
    }
  }, []);

  const saveToHistory = (item: GeneratedAudioItem) => {
    const updated = [item, ...history.slice(0, 19)]; // keep 20 latest
    setHistory(updated);
    try {
      localStorage.setItem('dimts_audio_history', JSON.stringify(updated));
    } catch (e) {
      console.warn('Storage quota note:', e);
    }
  };

  const handleGenerateSolo = async (scriptText: string, voiceName: VoiceName, styleDesc: string) => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const response = await fetch('/api/tts/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'single',
          text: scriptText,
          voice: voiceName,
          style: styleDesc,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to synthesize speech.');
      }

      const newItem: GeneratedAudioItem = {
        id: Date.now().toString(),
        title: scriptText.slice(0, 36) + (scriptText.length > 36 ? '...' : ''),
        text: scriptText,
        mode: 'single',
        voice: voiceName,
        audioBase64: data.audioBase64,
        durationSeconds: data.durationSeconds,
        createdAt: Date.now(),
        model: 'gemini-3.8-flash-tts',
      };

      setCurrentTrack(newItem);
      saveToHistory(newItem);
      setSuccessToast(language === 'am' ? 'ድምፁ በተሳካ ሁኔታ ተፈጥሯል!' : 'Speech generated successfully!');
      setTimeout(() => setSuccessToast(null), 3000);
    } catch (err: any) {
      console.error('TTS generation error:', err);
      setErrorMessage(err.message || 'Error communicating with TTS server.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGenerateDialogue = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const response = await fetch('/api/tts/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'dialogue',
          speaker1Config: speaker1,
          speaker2Config: speaker2,
          dialogueLines,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to synthesize dialogue.');
      }

      const previewText = dialogueLines
        .map((l) => `${l.speaker}: ${l.text}`)
        .join(' | ')
        .slice(0, 80);

      const newItem: GeneratedAudioItem = {
        id: Date.now().toString(),
        title: `${speaker1.name} & ${speaker2.name} Podcast Dialogue`,
        text: previewText,
        mode: 'dialogue',
        voice: `${speaker1.voice} + ${speaker2.voice}`,
        audioBase64: data.audioBase64,
        durationSeconds: data.durationSeconds,
        createdAt: Date.now(),
        model: 'gemini-3.8-flash-tts',
      };

      setCurrentTrack(newItem);
      saveToHistory(newItem);
      setSuccessToast(language === 'am' ? 'የሁለት ሰው ውይይት ድምፅ ተጠናቋል!' : 'Dual-speaker audio generated!');
      setTimeout(() => setSuccessToast(null), 3000);
    } catch (err: any) {
      console.error('TTS Dialogue error:', err);
      setErrorMessage(err.message || 'Error generating dialogue audio.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSelectPreset = (preset: PresetScript) => {
    if (preset.mode === 'dialogue') {
      if (preset.speaker1) setSpeaker1(preset.speaker1);
      if (preset.speaker2) setSpeaker2(preset.speaker2);
      if (preset.dialogueLines) setDialogueLines(preset.dialogueLines);
      setActiveTab('dialogue');
    } else {
      if (preset.text) setText(preset.text);
      if (preset.voice) setVoice(preset.voice);
      if (preset.style) setStyle(preset.style);
      setActiveTab('solo');
    }

    setSuccessToast(
      language === 'am'
        ? `«${preset.titleAm}» ናሙና ወደ ስቱዲዮ ተጭኗል!`
        : `Loaded "${preset.titleEn}" into studio!`
    );
    setTimeout(() => setSuccessToast(null), 2500);
  };

  const handleDeleteHistoryItem = (id: string) => {
    const updated = history.filter((item) => item.id !== id);
    setHistory(updated);
    localStorage.setItem('dimts_audio_history', JSON.stringify(updated));
  };

  const handleClearHistory = () => {
    setHistory([]);
    localStorage.removeItem('dimts_audio_history');
  };

  const handleLoadScriptToStudio = (item: GeneratedAudioItem) => {
    setText(item.text);
    setActiveTab('solo');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-amber-500 selection:text-slate-950">
      {/* Top Header */}
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-amber-400 to-emerald-500 p-0.5 shadow-lg shadow-amber-500/20 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Radio className="w-5 h-5 text-amber-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-base sm:text-lg tracking-tight bg-gradient-to-r from-amber-300 via-amber-100 to-emerald-300 bg-clip-text text-transparent">
                  ድምጽ Studio
                </h1>
                <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  gemini-3.8-flash-tts
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Ethiopian & Multilingual AI Text-to-Speech Engine
              </p>
            </div>
          </div>

          {/* Navigation and Language Switcher */}
          <div className="flex items-center gap-2">
            <div className="hidden md:flex items-center p-1 rounded-xl bg-slate-900 border border-slate-800">
              <button
                type="button"
                onClick={() => setActiveTab('solo')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                  activeTab === 'solo'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Mic className="w-3.5 h-3.5" />
                <span>{language === 'am' ? 'ነጠላ ድምፅ' : 'Solo Voice'}</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('dialogue')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                  activeTab === 'dialogue'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>{language === 'am' ? 'የሁለት ሰው ውይይት' : 'Dual Dialogue'}</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('presets')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                  activeTab === 'presets'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>{language === 'am' ? 'ናሙናዎች' : 'Presets'}</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('history')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition ${
                  activeTab === 'history'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                <span>{language === 'am' ? 'ታሪክ' : 'Library'}</span>
                {history.length > 0 && (
                  <span className="w-4 h-4 rounded-full bg-slate-800 text-[10px] flex items-center justify-center">
                    {history.length}
                  </span>
                )}
              </button>
            </div>

            {/* Language toggle button */}
            <button
              type="button"
              onClick={() => setLanguage(language === 'am' ? 'en' : 'am')}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-bold text-amber-300 flex items-center gap-1.5 transition shadow-sm"
              title="Switch language / ቋንቋ ቀይር"
            >
              <Languages className="w-3.5 h-3.5" />
              <span>{language === 'am' ? 'EN' : 'አማርኛ'}</span>
            </button>
          </div>
        </div>

        {/* Mobile Navigation Tabs */}
        <div className="flex md:hidden border-t border-slate-800/80 bg-slate-950 px-2 py-1 overflow-x-auto gap-1">
          <button
            onClick={() => setActiveTab('solo')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-medium whitespace-nowrap text-center ${
              activeTab === 'solo' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
          >
            {language === 'am' ? 'ነጠላ ድምፅ' : 'Solo'}
          </button>
          <button
            onClick={() => setActiveTab('dialogue')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-medium whitespace-nowrap text-center ${
              activeTab === 'dialogue' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
          >
            {language === 'am' ? 'የሁለት ሰው ውይይት' : 'Dialogue'}
          </button>
          <button
            onClick={() => setActiveTab('presets')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-medium whitespace-nowrap text-center ${
              activeTab === 'presets' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
          >
            {language === 'am' ? 'ናሙናዎች' : 'Presets'}
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-medium whitespace-nowrap text-center ${
              activeTab === 'history' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
          >
            {language === 'am' ? 'ታሪክ' : 'Library'}
          </button>
        </div>
      </header>

      {/* Hero Accent Bar with Ethiopian Flag Colors */}
      <div className="h-1 w-full bg-gradient-to-r from-emerald-500 via-amber-400 to-red-500 opacity-80" />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
        {/* Toast / Notification Banners */}
        {errorMessage && (
          <div className="p-4 rounded-xl bg-red-500/15 border border-red-500/40 text-red-300 text-xs sm:text-sm flex items-start gap-3 animate-in fade-in">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-semibold block mb-0.5">
                {language === 'am' ? 'ስህተት ተከስቷል' : 'Synthesis Error'}
              </span>
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-red-400 hover:text-white text-xs px-2 py-1 rounded bg-red-500/20"
            >
              ✕
            </button>
          </div>
        )}

        {successToast && (
          <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs sm:text-sm flex items-center gap-2.5 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-medium">{successToast}</span>
          </div>
        )}

        {/* Studio Body based on Active Tab */}
        {activeTab === 'solo' && (
          <SingleSpeakerStudio
            language={language}
            onGenerate={handleGenerateSolo}
            isLoading={isLoading}
            onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
            text={text}
            setText={setText}
            voice={voice}
            setVoice={setVoice}
            style={style}
            setStyle={setStyle}
          />
        )}

        {activeTab === 'dialogue' && (
          <DualSpeakerStudio
            language={language}
            speaker1={speaker1}
            setSpeaker1={setSpeaker1}
            speaker2={speaker2}
            setSpeaker2={setSpeaker2}
            dialogueLines={dialogueLines}
            setDialogueLines={setDialogueLines}
            onGenerateDialogue={handleGenerateDialogue}
            isLoading={isLoading}
            onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
          />
        )}

        {activeTab === 'presets' && (
          <PresetsSection
            language={language}
            onSelectPreset={handleSelectPreset}
          />
        )}

        {activeTab === 'history' && (
          <HistorySection
            language={language}
            history={history}
            onPlayItem={(item) => setCurrentTrack(item)}
            onDeleteItem={handleDeleteHistoryItem}
            onClearHistory={handleClearHistory}
            onLoadScriptToStudio={handleLoadScriptToStudio}
          />
        )}

        {/* Global Prominent Audio Player Bar */}
        <div className="pt-2">
          <AudioPlayerBar currentTrack={currentTrack} language={language} />
        </div>
      </main>

      {/* AI Script Assistant Modal */}
      <ScriptAssistantModal
        isOpen={isAiAssistantOpen}
        onClose={() => setIsAiAssistantOpen(false)}
        language={language}
        currentText={text}
        activeMode={activeTab === 'dialogue' ? 'dialogue' : 'single'}
        onApplyScript={(newScript) => {
          setText(newScript);
          setSuccessToast(language === 'am' ? 'ስክሪፕቱ ወደ ስቱዲዮ ተላልፏል!' : 'Script applied to studio!');
          setTimeout(() => setSuccessToast(null), 2500);
        }}
        onApplyDialogue={(lines) => {
          const formatted = lines.map((l, idx) => ({
            id: (idx + 1).toString(),
            speaker: l.speaker || (idx % 2 === 0 ? speaker1.name : speaker2.name),
            text: l.text,
            style: 'Expressive spoken tone',
          }));
          setDialogueLines(formatted);
          setActiveTab('dialogue');
          setSuccessToast(language === 'am' ? 'የውይይት መስመሮቹ ተጭነዋል!' : 'Dialogue lines applied!');
          setTimeout(() => setSuccessToast(null), 2500);
        }}
      />

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300">ድምጽ Studio</span>
            <span>•</span>
            <span>Powered by Gemini 3.8 Flash TTS & Flash Models</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Amharic, Tigrinya, Afaan Oromoo & English Speech</span>
            <span>•</span>
            <span className="text-amber-400/80">24kHz Studio Audio</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
