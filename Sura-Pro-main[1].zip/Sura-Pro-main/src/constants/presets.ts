import { VoiceOption, PresetScript } from '../types';

export const VOICES: VoiceOption[] = [
  {
    id: 'Kore',
    name: 'Kore',
    amharicName: 'ኮሬ (ሴት)',
    gender: 'Female',
    description: 'Warm, clear, natural and soothing. Ideal for narration and storytelling.',
    amharicDesc: 'ለስላሳ፣ ጥርት ያለ እና አሳማኝ የሴት ድምፅ። ለትረካ እና ለዜና ተስማሚ።',
    tags: ['Narrative', 'Clear', 'Warm'],
  },
  {
    id: 'Puck',
    name: 'Puck',
    amharicName: 'ፓክ (ወንድ)',
    gender: 'Male',
    description: 'Energetic, articulate, bright and friendly. Great for podcasts & dialogues.',
    amharicDesc: 'ቀልጣፋ፣ ንቁ እና ወጣት የድምፅ ቃና። ለውይይትና ለፖድካስት ተመራጭ።',
    tags: ['Lively', 'Friendly', 'Podcast'],
  },
  {
    id: 'Charon',
    name: 'Charon',
    amharicName: 'ሻሮን (ጥልቅ ወንድ)',
    gender: 'Male',
    description: 'Deep, resonant, authoritative, and serious. Superb for announcements.',
    amharicDesc: 'ጥልቅ፣ ግርማ ሞገስ ያለው እና ባለስልጣን የድምፅ ቃና። ለከባድ ማስታወቂያዎች።',
    tags: ['Deep', 'Authoritative', 'News'],
  },
  {
    id: 'Fenrir',
    name: 'Fenrir',
    amharicName: 'ፈንሪር (የሰከነ ወንድ)',
    gender: 'Male',
    description: 'Grounded, thoughtful, textured and mature storytelling tone.',
    amharicDesc: 'የሰከነ፣ አስተዋይ እና ልምድ ያካበተ ትረካ አቅራቢ።',
    tags: ['Calm', 'Thoughtful', 'Grounded'],
  },
  {
    id: 'Zephyr',
    name: 'Zephyr',
    amharicName: 'ዜፊር (ለስላሳ)',
    gender: 'Neutral',
    description: 'Gentle, balanced, conversational, and soft-spoken.',
    amharicDesc: 'እርጋታ የተሞላበት፣ ሰላማዊ እና ደስ የሚል ለስላሳ ድምፅ።',
    tags: ['Gentle', 'Soft', 'Meditation'],
  },
];

export const STYLE_PRESETS = [
  {
    label: '🇪🇹 Ethiopian Storyteller',
    labelAm: 'የኢትዮጵያ ባህላዊ ተራኪ',
    value: 'Warm, authentic Ethiopian storyteller with natural pronunciation, gentle cadence, and emotional warmth',
  },
  {
    label: '🎙️ Official News Anchor',
    labelAm: 'የዜና አቅራቢ',
    value: 'Clear, authoritative, professional broadcast journalist with crisp articulation and measured pace',
  },
  {
    label: '☕ Buna Ceremony Host (የቡና ጠሪ)',
    labelAm: 'የቡና ሥነ-ስርዓት ጠሪ',
    value: 'Welcoming, heartfelt, cheerful host inviting neighbors for traditional coffee ceremony',
  },
  {
    label: '💬 Casual Conversational',
    labelAm: 'የዕለት ተዕለት ውይይት',
    value: 'Relaxed, informal, friendly everyday conversational tone',
  },
  {
    label: '📜 Poetic & Philosophical',
    labelAm: 'ቅኔና ጥበብ የተሞላበት',
    value: 'Reflective, rhythmic, poetic delivery with thoughtful pauses on proverbs',
  },
  {
    label: '🚀 Tech & Innovation Host',
    labelAm: 'የቴክኖሎጂ እና አዳዲስ ፈጠራ',
    value: 'Inspiring, energetic modern tech presenter showcasing cutting edge breakthroughs',
  },
];

export const GEEZ_PUNCTUATIONS = [
  { symbol: '።', name: 'አራት ነጥብ (Period / Full Stop)' },
  { symbol: '፣', name: 'ነጠላ ሰረዝ (Comma)' },
  { symbol: '፤', name: 'ድርብ ሰረዝ (Semicolon)' },
  { symbol: '፦', name: 'ይዘት መግለጫ (Colon)' },
  { symbol: '፧', name: 'ጥያቄ ምልክት (Question Mark)' },
  { symbol: '፨', name: 'ምዕራፍ መዝጊያ (Paragraph End)' },
];

export const VOCAL_BURSTS = [
  { tag: '<breath>', label: '🌬️ Breath', hint: 'Natural breathing pause' },
  { tag: '<laugh>', label: '😄 Laugh', hint: 'Audible warm chuckle' },
  { tag: '<gasp>', label: '😮 Gasp', hint: 'Surprise or pause intake' },
  { tag: '|yeah|', label: '👍 |yeah|', hint: 'Podcast backchannel agree' },
  { tag: '|mhm|', label: '🤝 |mhm|', hint: 'Attentive listening backchannel' },
];

export const PRESET_SCRIPTS: PresetScript[] = [
  {
    id: 'welcome-amharic',
    titleEn: 'Warm Welcome to Dimts Studio',
    titleAm: 'የእንኳን ደህና መጡ ሰላምታ',
    category: 'greeting',
    mode: 'single',
    voice: 'Kore',
    style: 'Warm, welcoming, joyful Ethiopian host greeting guests',
    text: 'ሰላም ሰላም እንኳን ደህና መጡ! ወደ ድምጽ ስቱዲዮ እንኳን በደህና መጡ። <breath> እዚህ ጽሑፍዎን ወደ ሕያው፣ ጥርት ያለ እና አስደናቂ የተፈጥሮ ድምፅ መለወጥ ይችላሉ። ድምፃችንን ያዳምጡ፣ በፈጠራዎ ይደሰቱ!',
    description: 'The iconic Amharic welcoming greeting with natural intonation and warmth.',
  },
  {
    id: 'coffee-ceremony',
    titleEn: 'Ethiopian Coffee Ceremony (የቡና ቁርስ)',
    titleAm: 'የኢትዮጵያ የቡና ሥነ-ስርዓት',
    category: 'culture',
    mode: 'single',
    voice: 'Fenrir',
    style: 'Warm, authentic Ethiopian storyteller with gentle cadence and cultural pride',
    text: 'ቡና በኢትዮጵያ ባህል ውስጥ የመተሳሰብ፣ የፍቅርና የወሬ ማጣፈጫ ነው። <breath> የዕጣኑ ጭስ ሲወጣ፣ የጀበናው ቡና ሲፈላ፣ ጎረቤት ሁሉ ተሰብስቦ ይጨዋወታል። አቦል፣ ቶና፣ በረካ እያለ የቀረበው ቡና ልብን ያሞቃል፤ ፍቅርን ያፀናል።',
    description: 'A poetic celebration of the traditional Ethiopian Buna ceremony.',
  },
  {
    id: 'podcast-tech-dialogue',
    titleEn: 'Addis Tech Podcast (Dual-Speaker)',
    titleAm: 'የአዲስ አበባ ቴክ ፖድካስት (የሁለት ሰው ውይይት)',
    category: 'dialogue',
    mode: 'dialogue',
    description: 'Natural two-speaker conversation demonstrating dual-speaker Gemini TTS synthesis.',
    speaker1: {
      name: 'Almaz',
      voice: 'Kore',
      style: 'Enthusiastic, bright tech podcast host',
    },
    speaker2: {
      name: 'Bekele',
      voice: 'Fenrir',
      style: 'Curious, thoughtful tech enthusiast',
    },
    dialogueLines: [
      {
        id: '1',
        speaker: 'Almaz',
        text: 'ሰላም በቀለ! <breath> በቅርቡ የተለቀቀውን አዲሱን የሰው ሠራሽ አስተውሎት የድምፅ ቴክኖሎጂ ሞከርከው?',
        style: 'Enthusiastic greeting with bright curiosity',
      },
      {
        id: '2',
        speaker: 'Bekele',
        text: 'አዎ አልማዝ፣ |yeah| በጣም የሚገርም ነው! <laugh> አማርኛን ሳይቀር ልክ እንደ አገሬው ሰው አጥርቶ ይናገራል።',
        style: 'Amazed and laughing warmly',
      },
      {
        id: '3',
        speaker: 'Almaz',
        text: 'በትክክል! <breath> አሁን የትምህርት፣ የመጽሐፍት እና የፊልም ድምፆችን በከፍተኛ ጥራት ማዘጋጀት ተችሏል።',
        style: 'Passionate and articulate explanation',
      },
      {
        id: '4',
        speaker: 'Bekele',
        text: 'እውነትሽን ነው፣ |mhm| ይህ ለሀገራችን የዲጂታል እድገት ትልቅ እርምጃ ነው።',
        style: 'Reflective and nodding agreement',
      },
    ],
  },
  {
    id: 'wisdom-proverbs',
    titleEn: 'Ethiopian Proverbs & Wisdom',
    titleAm: 'የአባቶች ምክር እና ጥበብ',
    category: 'wisdom',
    mode: 'single',
    voice: 'Charon',
    style: 'Deep, wise, resonant traditional elder sharing ancestral philosophy',
    text: 'ድር ቢያብር አንበሳ ያስር ይባላል። አንድነት ኃይል ነው፤ በትብብር እና በሰላም አብሮ መኖር ታላቅ በረከት ነው። ሰው ለሰው መድሃኒት ነው፤ እጅ ለእጅ ተያይዘን ለበጎ ነገር እንትጋ።',
    description: 'Classic Ethiopian wisdom illustrating unity, solidarity, and peace.',
  },
  {
    id: 'lalibela-heritage',
    titleEn: 'Wonders of Lalibela (Historical)',
    titleAm: 'የላሊበላ ድንቅ ቅርስ',
    category: 'history',
    mode: 'single',
    voice: 'Kore',
    style: 'Epic, awe-inspiring documentary narrator with reverence and poise',
    text: 'በአስራ ሁለተኛው መቶ ክፍለ ዘመን የተነፁት የላሊበላ ውቅር አብያተ ክርስቲያናት፣ የሰው ልጅ የስነ-ህንፃ ጥበብ እና የእምነት ፅናት ድንቅ ምስክሮች ናቸው። ከአንድ ወጥ አለት ተፈልፍለው የተሰሩት እነዚህ ድንቆች፣ ዛሬም ዓለምን በአግራሞት ያስደምማሉ።',
    description: 'Documentary narration about Lalibela rock-hewn churches.',
  },
  {
    id: 'english-studio-demo',
    titleEn: 'English Studio Intro & Gemini TTS',
    titleAm: 'የእንግሊዝኛ የድምፅ ማሳያ',
    category: 'english',
    mode: 'single',
    voice: 'Puck',
    style: 'Inspiring, energetic tech presenter delivering a dynamic product launch',
    text: 'Welcome to Dimts Studio, powered by Google Gemini 3.8 Flash TTS! <breath> You are listening to high-fidelity, emotionally nuanced synthetic speech with support for custom vocal bursts, rich pacing, and dual-speaker screenplay direction.',
    description: 'Crisp English speech demonstrating the expressiveness of the model.',
  },
];
