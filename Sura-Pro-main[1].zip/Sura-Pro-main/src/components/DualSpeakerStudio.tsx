import React from 'react';
import {
  Users,
  Plus,
  Trash2,
  Sparkles,
  Mic,
  MessageSquare,
  ArrowRightLeft,
} from 'lucide-react';
import { VOICES, VOCAL_BURSTS, GEEZ_PUNCTUATIONS } from '../constants/presets';
import { DialogueLine, SpeakerConfig, VoiceName } from '../types';

interface DualSpeakerStudioProps {
  language: 'en' | 'am';
  speaker1: SpeakerConfig;
  setSpeaker1: React.Dispatch<React.SetStateAction<SpeakerConfig>>;
  speaker2: SpeakerConfig;
  setSpeaker2: React.Dispatch<React.SetStateAction<SpeakerConfig>>;
  dialogueLines: DialogueLine[];
  setDialogueLines: React.Dispatch<React.SetStateAction<DialogueLine[]>>;
  onGenerateDialogue: () => Promise<void>;
  isLoading: boolean;
  onOpenAiAssistant: () => void;
}

export const DualSpeakerStudio: React.FC<DualSpeakerStudioProps> = ({
  language,
  speaker1,
  setSpeaker1,
  speaker2,
  setSpeaker2,
  dialogueLines,
  setDialogueLines,
  onGenerateDialogue,
  isLoading,
  onOpenAiAssistant,
}) => {
  const addLine = (speakerName: string) => {
    const newLine: DialogueLine = {
      id: Date.now().toString(),
      speaker: speakerName,
      text: '',
      style: 'Natural dialogue tone',
    };
    setDialogueLines([...dialogueLines, newLine]);
  };

  const updateLineText = (id: string, text: string) => {
    setDialogueLines(
      dialogueLines.map((line) => (line.id === id ? { ...line, text } : line))
    );
  };

  const toggleLineSpeaker = (id: string) => {
    setDialogueLines(
      dialogueLines.map((line) => {
        if (line.id !== id) return line;
        const newSpeaker = line.speaker === speaker1.name ? speaker2.name : speaker1.name;
        return { ...line, speaker: newSpeaker };
      })
    );
  };

  const removeLine = (id: string) => {
    if (dialogueLines.length <= 1) return;
    setDialogueLines(dialogueLines.filter((line) => line.id !== id));
  };

  const insertTagToLine = (id: string, tag: string) => {
    setDialogueLines(
      dialogueLines.map((line) => {
        if (line.id !== id) return line;
        const newText = line.text + (line.text.length > 0 && !line.text.endsWith(' ') ? ' ' : '') + tag;
        return { ...line, text: newText };
      })
    );
  };

  return (
    <div className="space-y-6">
      {/* Dual Speakers Configuration Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider">
              {language === 'am' ? 'የሁለቱ ተናጋሪዎች ማዋቀሪያ' : 'Dual Speaker Cast (gemini-3.8-flash-tts)'}
            </h3>
          </div>
          <span className="text-xs text-amber-400/90 font-medium bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20">
            Multi-Speaker Voice Synthesis
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Speaker 1 Card */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-amber-500/30">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wide">
                Speaker 1 (ተናጋሪ ፩)
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                Primary Host
              </span>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  {language === 'am' ? 'የተናጋሪው ስም' : 'Character Name'}
                </label>
                <input
                  type="text"
                  value={speaker1.name}
                  onChange={(e) => setSpeaker1({ ...speaker1, name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                  placeholder="e.g. Almaz"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    {language === 'am' ? 'የድምፅ ቅላጼ' : 'Voice Model'}
                  </label>
                  <select
                    value={speaker1.voice}
                    onChange={(e) => setSpeaker1({ ...speaker1, voice: e.target.value as VoiceName })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                  >
                    {VOICES.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({v.gender})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    {language === 'am' ? 'የንግግር ስልት' : 'Persona Style'}
                  </label>
                  <input
                    type="text"
                    value={speaker1.style}
                    onChange={(e) => setSpeaker1({ ...speaker1, style: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
                    placeholder="Enthusiastic podcast host"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Speaker 2 Card */}
          <div className="p-4 rounded-xl bg-slate-950/70 border border-emerald-500/30">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wide">
                Speaker 2 (ተናጋሪ ፪)
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                Co-Host / Guest
              </span>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  {language === 'am' ? 'የተናጋሪው ስም' : 'Character Name'}
                </label>
                <input
                  type="text"
                  value={speaker2.name}
                  onChange={(e) => setSpeaker2({ ...speaker2, name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-400"
                  placeholder="e.g. Bekele"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    {language === 'am' ? 'የድምፅ ቅላጼ' : 'Voice Model'}
                  </label>
                  <select
                    value={speaker2.voice}
                    onChange={(e) => setSpeaker2({ ...speaker2, voice: e.target.value as VoiceName })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-400"
                  >
                    {VOICES.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({v.gender})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    {language === 'am' ? 'የንግግር ስልት' : 'Persona Style'}
                  </label>
                  <input
                    type="text"
                    value={speaker2.style}
                    onChange={(e) => setSpeaker2({ ...speaker2, style: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-emerald-400"
                    placeholder="Thoughtful tech guest"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Screenplay Lines Section */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider">
              {language === 'am' ? 'የውይይት መስመሮች (Screenplay Dialogue)' : 'Screenplay Dialogue Lines'}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenAiAssistant}
              className="px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500/20 to-emerald-500/20 border border-amber-500/40 text-amber-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'am' ? 'ውይይት በ AI ጻፍ' : 'AI Script Generator'}</span>
            </button>
          </div>
        </div>

        {/* Global Toolbar for inserting tokens */}
        <div className="flex flex-wrap items-center gap-1.5 mb-4 p-2 bg-slate-950/70 rounded-xl border border-slate-800">
          <span className="text-[11px] text-amber-400 font-semibold px-1">
            {language === 'am' ? 'የንግግር ማጣፈጫዎች (Backchannels & Bursts):' : 'Backchannels & Bursts:'}
          </span>
          {VOCAL_BURSTS.map((b) => (
            <span
              key={b.tag}
              className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-900 text-amber-300 border border-slate-800"
              title={b.hint}
            >
              {b.tag}
            </span>
          ))}
          <span className="text-[11px] text-slate-500 ml-1">
            ({language === 'am' ? 'በቀጥታ በመስመሩ ጽሑፍ ውስጥ ይካተታሉ' : 'Type or insert inside the lines below'})
          </span>
        </div>

        {/* Dialogue Lines Editor */}
        <div className="space-y-3">
          {dialogueLines.map((line, idx) => {
            const isSpeaker1 = line.speaker === speaker1.name;
            return (
              <div
                key={line.id}
                className={`p-3.5 rounded-xl border transition-all ${
                  isSpeaker1
                    ? 'bg-slate-950/80 border-amber-500/40 shadow-sm'
                    : 'bg-slate-950/80 border-emerald-500/40 shadow-sm'
                }`}
              >
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 font-mono">#{idx + 1}</span>
                    <button
                      type="button"
                      onClick={() => toggleLineSpeaker(line.id)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5 border transition ${
                        isSpeaker1
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      }`}
                    >
                      <ArrowRightLeft className="w-3 h-3" />
                      <span>{line.speaker}</span>
                    </button>
                    <span className="text-[11px] text-slate-400 hidden sm:inline">
                      ({isSpeaker1 ? speaker1.voice : speaker2.voice})
                    </span>
                  </div>

                  <div className="flex items-center gap-1">
                    {/* Quick tag inserters for this line */}
                    {['<breath>', '<laugh>', '|yeah|', '|mhm|'].map((tag) => (
                      <button
                        key={tag}
                        type="button"
                        onClick={() => insertTagToLine(line.id, tag)}
                        className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 transition"
                      >
                        {tag}
                      </button>
                    ))}
                    {dialogueLines.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeLine(line.id)}
                        className="p-1 rounded text-slate-500 hover:text-red-400 hover:bg-slate-800 transition"
                        title="Delete line"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <textarea
                  rows={2}
                  value={line.text}
                  onChange={(e) => updateLineText(line.id, e.target.value)}
                  placeholder={`What does ${line.speaker} say here?`}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2.5 text-xs sm:text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-400 leading-relaxed"
                />
              </div>
            );
          })}
        </div>

        {/* Action Buttons to Add Lines */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-3 border-t border-slate-800">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => addLine(speaker1.name)}
              className="px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-semibold flex items-center gap-1 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ {speaker1.name}</span>
            </button>
            <button
              type="button"
              onClick={() => addLine(speaker2.name)}
              className="px-3 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1 transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>+ {speaker2.name}</span>
            </button>
          </div>

          <button
            type="button"
            disabled={isLoading || dialogueLines.every((l) => !l.text.trim())}
            onClick={onGenerateDialogue}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-emerald-600 hover:from-amber-400 hover:to-emerald-500 text-slate-950 font-bold text-sm sm:text-base flex items-center gap-2 shadow-lg shadow-amber-500/20 transition active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                <span>{language === 'am' ? 'ውይይቱን በማቀናበር ላይ...' : 'Rendering Dual-Speaker Audio...'}</span>
              </>
            ) : (
              <>
                <Mic className="w-5 h-5" />
                <span>
                  {language === 'am' ? 'የሁለት ሰው ድምፅ አፍልቅ (Synthesize Dialogue)' : 'Synthesize Screenplay Dialogue'}
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
