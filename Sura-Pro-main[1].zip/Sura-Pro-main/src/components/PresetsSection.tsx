import React from 'react';
import { Sparkles, Play, ArrowRight, BookOpen, Coffee, MessageSquare, Landmark, Award } from 'lucide-react';
import { PRESET_SCRIPTS } from '../constants/presets';
import { PresetScript } from '../types';

interface PresetsSectionProps {
  language: 'en' | 'am';
  onSelectPreset: (preset: PresetScript) => void;
}

export const PresetsSection: React.FC<PresetsSectionProps> = ({ language, onSelectPreset }) => {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'greeting':
        return <Sparkles className="w-4 h-4 text-amber-400" />;
      case 'culture':
        return <Coffee className="w-4 h-4 text-amber-500" />;
      case 'dialogue':
        return <MessageSquare className="w-4 h-4 text-emerald-400" />;
      case 'wisdom':
        return <BookOpen className="w-4 h-4 text-blue-400" />;
      case 'history':
        return <Landmark className="w-4 h-4 text-purple-400" />;
      default:
        return <Award className="w-4 h-4 text-emerald-400" />;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-400" />
            <span>{language === 'am' ? 'የተመረጡ የድምፅ ናሙናዎች' : 'Curated Ethiopian & Multilingual Presets'}</span>
          </h3>
          <p className="text-xs sm:text-sm text-slate-400">
            {language === 'am'
              ? 'በአንድ ጠቅታ የተዘጋጁትን የሰላምታ፣ የቡና ሥነ-ስርዓት፣ ወይም የፖድካስት ናሙናዎች ይጫኑ'
              : 'One-click load greetings, coffee folklore, tech podcasts, and wisdom scripts into the studio.'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {PRESET_SCRIPTS.map((preset) => {
          const isDialogue = preset.mode === 'dialogue';
          return (
            <div
              key={preset.id}
              onClick={() => onSelectPreset(preset)}
              className="group p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-amber-400/60 hover:bg-slate-850 transition-all cursor-pointer flex flex-col justify-between hover:shadow-lg hover:shadow-amber-500/10 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl group-hover:bg-amber-500/10 transition" />

              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-slate-800 border border-slate-700">
                      {getCategoryIcon(preset.category)}
                    </div>
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      {preset.category}
                    </span>
                  </div>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                      isDialogue
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}
                  >
                    {isDialogue ? '2 Speakers' : preset.voice}
                  </span>
                </div>

                <h4 className="text-sm sm:text-base font-bold text-white group-hover:text-amber-300 transition">
                  {language === 'am' ? preset.titleAm : preset.titleEn}
                </h4>

                <p className="text-xs text-slate-400 line-clamp-3 mt-1.5 leading-relaxed">
                  {isDialogue
                    ? `${preset.dialogueLines?.[0]?.speaker}: "${preset.dialogueLines?.[0]?.text}"`
                    : preset.text}
                </p>
              </div>

              <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-800/80">
                <span className="text-[11px] text-slate-500">
                  {isDialogue ? `${preset.dialogueLines?.length || 4} lines dialogue` : preset.style?.split(',')[0]}
                </span>
                <span className="text-xs text-amber-400 font-semibold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  <span>{language === 'am' ? 'ሞክር' : 'Load'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
