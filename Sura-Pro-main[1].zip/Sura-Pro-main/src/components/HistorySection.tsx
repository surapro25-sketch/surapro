import React from 'react';
import {
  History,
  Play,
  Download,
  Trash2,
  Copy,
  Clock,
  ArrowRight,
  Music,
} from 'lucide-react';
import { GeneratedAudioItem } from '../types';

interface HistorySectionProps {
  language: 'en' | 'am';
  history: GeneratedAudioItem[];
  onPlayItem: (item: GeneratedAudioItem) => void;
  onDeleteItem: (id: string) => void;
  onClearHistory: () => void;
  onLoadScriptToStudio: (item: GeneratedAudioItem) => void;
}

export const HistorySection: React.FC<HistorySectionProps> = ({
  language,
  history,
  onPlayItem,
  onDeleteItem,
  onClearHistory,
  onLoadScriptToStudio,
}) => {
  const handleDownload = (item: GeneratedAudioItem) => {
    const link = document.createElement('a');
    link.href = `data:audio/wav;base64,${item.audioBase64}`;
    const cleanTitle = (item.title || 'dimts-audio')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
    link.download = `${cleanTitle || 'speech'}-${item.createdAt}.wav`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatDate = (timestamp: number) => {
    const d = new Date(timestamp);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' • ' + d.toLocaleDateString();
  };

  if (history.length === 0) {
    return (
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-8 text-center text-slate-400">
        <Music className="w-10 h-10 mx-auto text-slate-600 mb-3" />
        <h4 className="text-base font-semibold text-slate-300 mb-1">
          {language === 'am' ? 'ምንም የተፈጠረ ድምፅ እስካሁን የለም' : 'No Generated Audio Yet'}
        </h4>
        <p className="text-xs text-slate-500 max-w-sm mx-auto">
          {language === 'am'
            ? 'በስቱዲዮ ውስጥ ጽሑፍ ያስገቡና «ድምፅ አፍልቅ» የሚለውን ይጫኑ፤ እዚህ ይቀመጣል።'
            : 'Generated voice tracks with gemini-3.8-flash-tts will automatically be saved here.'}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5 text-amber-400" />
          <h3 className="text-base sm:text-lg font-bold text-white">
            {language === 'am' ? 'የድምፅ ታሪክ (Audio Library)' : 'Generation History & Audio Library'}
          </h3>
          <span className="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-slate-400">
            {history.length}
          </span>
        </div>

        <button
          type="button"
          onClick={onClearHistory}
          className="text-xs text-slate-400 hover:text-red-400 transition flex items-center gap-1"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>{language === 'am' ? 'ሁሉንም አጽዳ' : 'Clear All'}</span>
        </button>
      </div>

      <div className="space-y-2.5">
        {history.map((item) => (
          <div
            key={item.id}
            className="p-3.5 sm:p-4 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition"
          >
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 mb-1 flex-wrap">
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  {item.voice}
                </span>
                <span className="text-[11px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">
                  {item.mode === 'dialogue' ? 'Dual Speaker' : 'Solo'}
                </span>
                <span className="text-[11px] text-slate-500 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {formatDate(item.createdAt)}
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-200 line-clamp-2 leading-relaxed">
                "{item.text}"
              </p>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
              <button
                type="button"
                onClick={() => onPlayItem(item)}
                className="px-3 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-semibold text-xs flex items-center gap-1.5 transition active:scale-95 shadow-md shadow-amber-400/20"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{language === 'am' ? 'አጫውት' : 'Play'}</span>
              </button>

              <button
                type="button"
                onClick={() => handleDownload(item)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition text-xs"
                title="Download WAV"
              >
                <Download className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => onLoadScriptToStudio(item)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-amber-300 transition text-xs"
                title="Edit script in studio"
              >
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => onDeleteItem(item.id)}
                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-red-400 transition text-xs"
                title="Delete"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
