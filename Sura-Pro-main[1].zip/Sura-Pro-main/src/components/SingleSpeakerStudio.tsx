import React, { useState } from 'react';
import {
  Mic,
  Sparkles,
  Wand2,
  Volume2,
  Trash2,
  Copy,
  Check,
  Flame,
  Info,
} from 'lucide-react';
import { VOICES, STYLE_PRESETS, GEEZ_PUNCTUATIONS, VOCAL_BURSTS } from '../constants/presets';
import { VoiceName } from '../types';

interface SingleSpeakerStudioProps {
  language: 'en' | 'am';
  onGenerate: (text: string, voice: VoiceName, style: string) => Promise<void>;
  isLoading: boolean;
  onOpenAiAssistant: () => void;
  text: string;
  setText: (val: string) => void;
  voice: VoiceName;
  setVoice: (val: VoiceName) => void;
  style: string;
  setStyle: (val: string) => void;
}

export const SingleSpeakerStudio: React.FC<SingleSpeakerStudioProps> = ({
  language,
  onGenerate,
  isLoading,
  onOpenAiAssistant,
  text,
  setText,
  voice,
  setVoice,
  style,
  setStyle,
}) => {
  const [copied, setCopied] = useState(false);
  const [customStyleOpen, setCustomStyleOpen] = useState(false);

  const insertAtCursor = (symbol: string) => {
    setText(text + (text.length > 0 && !text.endsWith(' ') ? ' ' : '') + symbol);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  const charCount = text.length;

  return (
    <div className="space-y-6">
      {/* Voice Selection Section */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider">
              {language === 'am' ? 'የድምፅ ምርጫ' : 'Voice Selection'}
            </h3>
          </div>
          <span className="text-xs text-slate-400">
            {language === 'am' ? 'ሞዴል፡ gemini-3.8-flash-tts' : 'Engine: gemini-3.8-flash-tts'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {VOICES.map((v) => {
            const isSelected = voice === v.id;
            return (
              <button
                key={v.id}
                type="button"
                onClick={() => setVoice(v.id)}
                className={`text-left p-3.5 rounded-xl border transition-all relative ${
                  isSelected
                    ? 'bg-amber-500/15 border-amber-400 shadow-md shadow-amber-500/10'
                    : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-800/50'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                        isSelected ? 'bg-amber-400 text-slate-950' : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {v.name[0]}
                    </div>
                    <div>
                      <span className="font-semibold text-sm text-white block">
                        {v.name}
                      </span>
                      <span className="text-[11px] text-amber-300/80">
                        {v.amharicName}
                      </span>
                    </div>
                  </div>
                  {isSelected && (
                    <span className="w-2 h-2 rounded-full bg-amber-400 ring-4 ring-amber-400/20" />
                  )}
                </div>
                <p className="text-xs text-slate-400 line-clamp-2 mt-1 leading-relaxed">
                  {language === 'am' ? v.amharicDesc : v.description}
                </p>
                <div className="flex flex-wrap gap-1 mt-2">
                  {v.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800/80 text-slate-300 border border-slate-700/50"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Style & Emotion Director */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider">
              {language === 'am' ? 'የድምፅ ባህሪና ስሜት (Style & Tone)' : 'Speech Style & Persona'}
            </h3>
          </div>
          <button
            type="button"
            onClick={() => setCustomStyleOpen(!customStyleOpen)}
            className="text-xs text-amber-400 hover:text-amber-300 transition"
          >
            {customStyleOpen
              ? (language === 'am' ? 'ናሙናዎችን አሳይ' : 'Show Presets')
              : (language === 'am' ? 'የራስዎን ይፃፉ' : 'Custom Prompt')}
          </button>
        </div>

        {!customStyleOpen ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {STYLE_PRESETS.map((p) => {
              const isSelected = style === p.value;
              return (
                <button
                  key={p.value}
                  type="button"
                  onClick={() => setStyle(p.value)}
                  className={`text-left p-2.5 rounded-xl border text-xs transition ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-400 text-amber-200 font-medium'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="font-semibold mb-0.5">
                    {language === 'am' ? p.labelAm : p.label}
                  </div>
                  <div className="text-[11px] text-slate-400 line-clamp-1">
                    {p.value}
                  </div>
                </button>
              );
            })}
          </div>
        ) : (
          <div>
            <textarea
              rows={2}
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              placeholder="e.g. Warm, authentic Ethiopian storyteller with gentle cadence and emotional warmth..."
              className="w-full bg-slate-950/90 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-amber-400"
            />
          </div>
        )}
      </div>

      {/* Script Text Input Area */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-5 relative">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <Mic className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-slate-200 uppercase tracking-wider">
              {language === 'am' ? 'የሚነበብ ጽሑፍ' : 'Script Content'}
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onOpenAiAssistant}
              className="px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-amber-500/20 to-emerald-500/20 border border-amber-500/40 text-amber-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition hover:scale-[1.02]"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>{language === 'am' ? 'በ AI አዘጋጅ' : 'AI Assistant'}</span>
            </button>
            <button
              type="button"
              onClick={handleCopy}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition text-xs"
              title="Copy"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
            <button
              type="button"
              onClick={() => setText('')}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-red-400 transition text-xs"
              title="Clear"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Amharic / Ge'ez Punctuation toolbar */}
        <div className="flex flex-wrap items-center gap-1.5 mb-2.5 p-2 bg-slate-950/70 rounded-xl border border-slate-800">
          <span className="text-[11px] text-amber-400 font-semibold px-1">
            {language === 'am' ? 'የግዕዝ ሥርዓተ-ነጥቦች፡' : "Ge'ez Marks:"}
          </span>
          {GEEZ_PUNCTUATIONS.map((p) => (
            <button
              key={p.symbol}
              type="button"
              onClick={() => insertAtCursor(p.symbol)}
              title={p.name}
              className="px-2 py-1 rounded bg-slate-900 hover:bg-amber-500/20 hover:text-amber-300 text-slate-300 border border-slate-800 text-xs font-bold transition"
            >
              {p.symbol}
            </button>
          ))}

          <span className="border-l border-slate-800 h-4 mx-1" />

          <span className="text-[11px] text-emerald-400 font-semibold px-1">
            {language === 'am' ? 'የድምፅ ምልክቶች፡' : 'Vocal Bursts:'}
          </span>
          {VOCAL_BURSTS.map((b) => (
            <button
              key={b.tag}
              type="button"
              onClick={() => insertAtCursor(b.tag)}
              title={b.hint}
              className="px-2 py-0.5 rounded bg-slate-900 hover:bg-emerald-500/20 hover:text-emerald-300 text-slate-300 border border-slate-800 text-[11px] font-mono transition"
            >
              {b.label}
            </button>
          ))}
        </div>

        <textarea
          rows={5}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={
            language === 'am'
              ? 'የሚፈለገውን ጽሑፍ እዚህ ይፃፉ... (ለምሳሌ፡ ሰላም ሰላም እንኳን ደህና መጡ! ወደ ድምጽ ስቱዲዮ እንኳን በደህና መጡ።)'
              : 'Type or paste the speech text here... Supports Amharic, English, and other languages.'
          }
          className="w-full bg-slate-950/90 border border-slate-800 rounded-xl p-3.5 text-sm sm:text-base text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/30 leading-relaxed font-normal"
        />

        <div className="flex items-center justify-between text-xs text-slate-500 mt-2 px-1">
          <div className="flex items-center gap-1.5 text-slate-400">
            <Info className="w-3.5 h-3.5 text-amber-400" />
            <span>
              {language === 'am'
                ? 'ምክር፡ ተፈጥሯዊ ትንፋሽ ለመጨመር <breath> ወይም <laugh> ይጠቀሙ።'
                : 'Tip: Add tags like <breath> or <laugh> for human-like pauses and smiles.'}
            </span>
          </div>
          <div>
            <span>{wordCount} words</span> • <span>{charCount} chars</span>
          </div>
        </div>

        {/* Generate Button */}
        <div className="mt-5 flex justify-end">
          <button
            type="button"
            disabled={isLoading || !text.trim()}
            onClick={() => onGenerate(text, voice, style)}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-600 to-amber-500 hover:from-amber-400 hover:to-amber-600 text-slate-950 font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-all transform active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                <span>{language === 'am' ? 'ድምፅ በመፍጠር ላይ...' : 'Synthesizing Audio...'}</span>
              </>
            ) : (
              <>
                <Mic className="w-5 h-5" />
                <span>
                  {language === 'am' ? 'ድምፅ አፍልቅ (Convert to Speech)' : 'Generate Speech'}
                </span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
