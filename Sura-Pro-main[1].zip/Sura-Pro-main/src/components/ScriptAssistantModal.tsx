import React, { useState } from 'react';
import {
  Sparkles,
  X,
  Wand2,
  Languages,
  Flame,
  Check,
  ArrowRight,
  MessageSquare,
} from 'lucide-react';

interface ScriptAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: 'en' | 'am';
  currentText: string;
  onApplyScript: (script: string) => void;
  onApplyDialogue?: (lines: Array<{ speaker: string; text: string }>) => void;
  activeMode: 'single' | 'dialogue';
}

export const ScriptAssistantModal: React.FC<ScriptAssistantModalProps> = ({
  isOpen,
  onClose,
  language,
  currentText,
  onApplyScript,
  onApplyDialogue,
  activeMode,
}) => {
  const [action, setAction] = useState<'generate' | 'translate' | 'add_bursts' | 'dialogue'>(
    activeMode === 'dialogue' ? 'dialogue' : 'generate'
  );
  const [prompt, setPrompt] = useState('');
  const [targetLang, setTargetLang] = useState('Amharic (አማርኛ)');
  const [generatedResult, setGeneratedResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleRunAi = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/ai/script-assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action,
          prompt,
          currentText,
          targetLanguage: targetLang,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate script assistance.');
      }

      setGeneratedResult(data.result);
    } catch (err: any) {
      setError(err.message || 'An error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleApply = () => {
    if (action === 'dialogue' && onApplyDialogue) {
      // Parse dialogue lines like "Speaker: text"
      const lines = generatedResult
        .split('\n')
        .map((l) => l.trim())
        .filter((l) => l.length > 0 && l.includes(':'));

      if (lines.length > 0) {
        const parsed = lines.map((l) => {
          const colonIdx = l.indexOf(':');
          return {
            speaker: l.substring(0, colonIdx).trim(),
            text: l.substring(colonIdx + 1).trim(),
          };
        });
        onApplyDialogue(parsed);
        onClose();
        return;
      }
    }

    onApplyScript(generatedResult);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-amber-500/40 w-full max-w-2xl rounded-2xl p-5 sm:p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">
              {language === 'am' ? 'የ AI ስክሪፕት አጋዥ (gemini-3.8-flash)' : 'AI Script Assistant (gemini-3.8-flash)'}
            </h3>
            <p className="text-xs text-slate-400">
              {language === 'am'
                ? 'የንግግር ስክሪፕት ይፍጠሩ፣ ወደ አማርኛ ይተርጉሙ፣ ወይም ተፈጥሯዊ የትንፋሽ ምልክቶችን ያክሉ'
                : 'Generate scripts, translate to spoken Amharic, or inject vocal burst tokens.'}
            </p>
          </div>
        </div>

        {/* Action Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
          <button
            type="button"
            onClick={() => setAction('generate')}
            className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition ${
              action === 'generate'
                ? 'bg-amber-500/20 text-amber-300 border-amber-400'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700'
            }`}
          >
            <Wand2 className="w-3.5 h-3.5" />
            <span>{language === 'am' ? 'ከሀሳብ ፍጠር' : 'From Prompt'}</span>
          </button>
          <button
            type="button"
            onClick={() => setAction('translate')}
            className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition ${
              action === 'translate'
                ? 'bg-amber-500/20 text-amber-300 border-amber-400'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700'
            }`}
          >
            <Languages className="w-3.5 h-3.5" />
            <span>{language === 'am' ? 'ተርጉም' : 'Translate'}</span>
          </button>
          <button
            type="button"
            onClick={() => setAction('add_bursts')}
            className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition ${
              action === 'add_bursts'
                ? 'bg-amber-500/20 text-amber-300 border-amber-400'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700'
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            <span>{language === 'am' ? 'ምልክቶች ጨምር' : 'Add Bursts'}</span>
          </button>
          <button
            type="button"
            onClick={() => setAction('dialogue')}
            className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 border transition ${
              action === 'dialogue'
                ? 'bg-amber-500/20 text-amber-300 border-amber-400'
                : 'bg-slate-950/60 text-slate-400 border-slate-800 hover:border-slate-700'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>{language === 'am' ? 'የሁለት ሰው ውይይት' : 'Dialogue'}</span>
          </button>
        </div>

        {/* Inputs based on action */}
        {action === 'generate' && (
          <div className="space-y-3 mb-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {language === 'am' ? 'ስለ ምን ዓይነት ርዕስ እንዲጻፍ ይፈልጋሉ?' : 'Describe what speech you want to generate:'}
              </label>
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g. A warm welcome speech in Amharic for an art exhibition in Addis Ababa..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-amber-400"
              />
            </div>
            <div className="flex gap-2">
              {['Ethiopian Coffee welcome', 'Addis Tech Innovation', 'Bedtime folk story', 'News announcement'].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setPrompt(s)}
                  className="text-[11px] px-2 py-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 transition"
                >
                  + {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {action === 'translate' && (
          <div className="space-y-3 mb-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {language === 'am' ? 'የሚተረጎም ጽሑፍ (ከዚህ በፊት የጻፉት)' : 'Source text to translate into natural spoken speech:'}
              </label>
              <textarea
                rows={3}
                value={currentText}
                readOnly
                className="w-full bg-slate-950/60 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-400 cursor-not-allowed"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {language === 'am' ? 'ዒላማ ቋንቋ' : 'Target Language'}
              </label>
              <select
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-400"
              >
                <option value="Amharic (አማርኛ)">Amharic (አማርኛ)</option>
                <option value="Tigrinya (ትግርኛ)">Tigrinya (ትግርኛ)</option>
                <option value="Afaan Oromoo">Afaan Oromoo</option>
                <option value="English">English</option>
              </select>
            </div>
          </div>
        )}

        {action === 'add_bursts' && (
          <div className="mb-4">
            <p className="text-xs text-slate-400 mb-2">
              Gemini will analyze your current text and insert natural pauses like{' '}
              <code className="text-amber-300">&lt;breath&gt;</code>,{' '}
              <code className="text-emerald-300">&lt;laugh&gt;</code>, or podcast agreements like{' '}
              <code className="text-amber-300">|yeah|</code>.
            </p>
            <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-xs text-slate-300 max-h-24 overflow-y-auto">
              {currentText || 'No text currently written. Type something in the studio first!'}
            </div>
          </div>
        )}

        {action === 'dialogue' && (
          <div className="space-y-3 mb-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                {language === 'am' ? 'የውይይት ርዕስ (Topic of conversation)' : 'Topic for two-speaker dialogue:'}
              </label>
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="e.g. Almaz and Bekele discussing new AI voice features in Addis Ababa..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs sm:text-sm text-slate-200 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs">
            {error}
          </div>
        )}

        {/* Generate Button */}
        <button
          type="button"
          onClick={handleRunAi}
          disabled={isLoading || (action !== 'add_bursts' && action !== 'translate' && !prompt.trim())}
          className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition disabled:opacity-50"
        >
          {isLoading ? (
            <>
              <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              <span>Thinking with Gemini 3.8 Flash...</span>
            </>
          ) : (
            <>
              <Wand2 className="w-4 h-4" />
              <span>{language === 'am' ? 'በ AI አመንጭ' : 'Generate with Gemini'}</span>
            </>
          )}
        </button>

        {/* Result Area */}
        {generatedResult && (
          <div className="mt-5 pt-4 border-t border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wide">
                {language === 'am' ? 'የተዘጋጀ ውጤት (Generated Result):' : 'Generated Result:'}
              </span>
            </div>
            <textarea
              rows={4}
              value={generatedResult}
              onChange={(e) => setGeneratedResult(e.target.value)}
              className="w-full bg-slate-950 border border-emerald-500/30 rounded-xl p-3 text-xs sm:text-sm text-slate-100 focus:outline-none focus:border-emerald-400 leading-relaxed font-normal"
            />
            <div className="flex justify-end gap-2 mt-3">
              <button
                type="button"
                onClick={handleApply}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-md shadow-emerald-500/20 transition active:scale-95"
              >
                <Check className="w-4 h-4" />
                <span>{language === 'am' ? 'ወደ ስቱዲዮ አስገባ (Apply to Studio)' : 'Apply to Studio'}</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
