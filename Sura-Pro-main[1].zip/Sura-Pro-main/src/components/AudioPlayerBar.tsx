import React, { useEffect, useRef, useState } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Download,
  Repeat,
  Sparkles,
  Share2,
  Check,
} from 'lucide-react';
import { AudioVisualizer } from './AudioVisualizer';
import { GeneratedAudioItem } from '../types';

interface AudioPlayerBarProps {
  currentTrack: GeneratedAudioItem | null;
  language: 'en' | 'am';
}

export const AudioPlayerBar: React.FC<AudioPlayerBarProps> = ({ currentTrack, language }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [isLooping, setIsLooping] = useState(false);
  const [copied, setCopied] = useState(false);

  // When track changes, auto load and play
  useEffect(() => {
    if (audioRef.current && currentTrack) {
      audioRef.current.currentTime = 0;
      setCurrentTime(0);
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch((e) => {
        console.warn('Autoplay prevented:', e);
        setIsPlaying(false);
      });
    }
  }, [currentTrack]);

  const togglePlay = () => {
    if (!audioRef.current || !currentTrack) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch((e) => {
        console.error('Play error:', e);
      });
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
      if (audioRef.current.duration && !isNaN(audioRef.current.duration)) {
        setDuration(audioRef.current.duration);
      }
    }
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current && !isNaN(audioRef.current.duration)) {
      setDuration(audioRef.current.duration);
    } else if (currentTrack?.durationSeconds) {
      setDuration(currentTrack.durationSeconds);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setCurrentTime(time);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseFloat(e.target.value);
    setVolume(vol);
    if (audioRef.current) {
      audioRef.current.volume = vol;
      setIsMuted(vol === 0);
    }
  };

  const toggleMute = () => {
    if (!audioRef.current) return;
    if (isMuted) {
      audioRef.current.volume = volume || 0.8;
      setIsMuted(false);
    } else {
      audioRef.current.volume = 0;
      setIsMuted(true);
    }
  };

  const handleSpeedChange = (speed: number) => {
    setPlaybackRate(speed);
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
  };

  const toggleLoop = () => {
    const next = !isLooping;
    setIsLooping(next);
    if (audioRef.current) {
      audioRef.current.loop = next;
    }
  };

  const restartAudio = () => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      setCurrentTime(0);
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleDownload = () => {
    if (!currentTrack) return;
    const link = document.createElement('a');
    link.href = `data:audio/wav;base64,${currentTrack.audioBase64}`;
    const cleanTitle = (currentTrack.title || 'dimts-speech')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');
    link.download = `${cleanTitle || 'speech'}-${Date.now()}.wav`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyLink = () => {
    if (!currentTrack) return;
    navigator.clipboard.writeText(currentTrack.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '0:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  if (!currentTrack) {
    return (
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 text-center text-slate-400">
        <div className="flex items-center justify-center gap-2 mb-1 text-slate-300 font-medium">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <span>{language === 'am' ? 'የድምፅ ማጫወቻ ዝግጁ ነው' : 'Audio Player Ready'}</span>
        </div>
        <p className="text-xs sm:text-sm text-slate-400">
          {language === 'am'
            ? 'ጽሑፍዎን አስገብተው «ድምፅ አፍልቅ» የሚለውን ይጫኑ ወይም ከናሙናዎቹ ይምረጡ።'
            : 'Enter your text or choose a preset script above to generate lifelike speech with gemini-3.8-flash-tts.'}
        </p>
      </div>
    );
  }

  const audioSrc = `data:audio/wav;base64,${currentTrack.audioBase64}`;

  return (
    <div className="bg-slate-900/95 backdrop-blur-md border border-amber-500/30 rounded-2xl p-4 sm:p-6 shadow-xl shadow-black/40 transition-all">
      <audio
        ref={audioRef}
        src={audioSrc}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={() => {
          if (!isLooping) setIsPlaying(false);
        }}
      />

      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
              gemini-3.8-flash-tts
            </span>
            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-slate-800 text-slate-300 border border-slate-700">
              {currentTrack.voice}
            </span>
            <span className="text-xs text-slate-400">
              {formatTime(currentTime)} / {formatTime(duration || currentTrack.durationSeconds)}
            </span>
          </div>
          <h3 className="text-base sm:text-lg font-semibold text-white truncate max-w-xl">
            {currentTrack.title}
          </h3>
          <p className="text-xs text-slate-400 line-clamp-1 mt-0.5 italic">
            "{currentTrack.text}"
          </p>
        </div>

        <div className="flex items-center gap-2 self-end lg:self-center">
          <button
            onClick={handleCopyLink}
            title={language === 'am' ? 'ጽሑፉን ኮፒ አድርግ' : 'Copy script text'}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition flex items-center gap-1.5 text-xs font-medium border border-slate-700"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
            <span className="hidden sm:inline">{copied ? (language === 'am' ? 'ተቀድቷል' : 'Copied') : (language === 'am' ? 'ኮፒ' : 'Copy')}</span>
          </button>
          <button
            onClick={handleDownload}
            title={language === 'am' ? 'በ WAV አውርድ' : 'Download WAV'}
            className="px-3 py-2 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-semibold text-xs sm:text-sm flex items-center gap-1.5 shadow-md shadow-amber-500/20 transition active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>{language === 'am' ? 'WAV አውርድ' : 'Download WAV'}</span>
          </button>
        </div>
      </div>

      {/* Visualizer */}
      <div className="mb-4">
        <AudioVisualizer isPlaying={isPlaying} audioElement={audioRef.current} />
      </div>

      {/* Scrub bar */}
      <div className="flex items-center gap-3 mb-4">
        <span className="text-xs text-slate-400 tabular-nums w-10 text-right">
          {formatTime(currentTime)}
        </span>
        <input
          type="range"
          min={0}
          max={duration || currentTrack.durationSeconds || 10}
          step={0.05}
          value={currentTime}
          onChange={handleSeek}
          className="flex-1 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
        />
        <span className="text-xs text-slate-400 tabular-nums w-10">
          {formatTime(duration || currentTrack.durationSeconds)}
        </span>
      </div>

      {/* Controls row */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-800">
        <div className="flex items-center gap-2">
          <button
            onClick={restartAudio}
            title={language === 'am' ? 'እንደገና ጀምር' : 'Restart'}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <button
            onClick={togglePlay}
            className="w-11 h-11 rounded-full bg-amber-400 hover:bg-amber-300 text-slate-950 flex items-center justify-center font-bold shadow-lg shadow-amber-400/30 transition active:scale-95"
          >
            {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
          </button>

          <button
            onClick={toggleLoop}
            title={language === 'am' ? 'በድጋሚ አጫውት' : 'Loop'}
            className={`p-2 rounded-lg transition ${
              isLooping ? 'text-amber-400 bg-amber-500/20 border border-amber-500/40' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Repeat className="w-4 h-4" />
          </button>
        </div>

        {/* Speed controls */}
        <div className="flex items-center gap-1 bg-slate-950/60 p-1 rounded-xl border border-slate-800">
          <span className="text-[11px] text-slate-500 px-2 font-medium">Speed:</span>
          {[0.75, 1, 1.25, 1.5].map((speed) => (
            <button
              key={speed}
              onClick={() => handleSpeedChange(speed)}
              className={`px-2 py-1 rounded-lg text-xs font-semibold transition ${
                playbackRate === speed
                  ? 'bg-amber-500 text-slate-950'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {speed}x
            </button>
          ))}
        </div>

        {/* Volume slider */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleMute}
            className="text-slate-400 hover:text-white transition p-1"
          >
            {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.05}
            value={isMuted ? 0 : volume}
            onChange={handleVolumeChange}
            className="w-20 sm:w-24 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
          />
        </div>
      </div>
    </div>
  );
};
