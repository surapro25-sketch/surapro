import React, { useEffect, useRef } from 'react';

interface AudioVisualizerProps {
  isPlaying: boolean;
  audioElement: HTMLAudioElement | null;
}

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({ isPlaying, audioElement }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameIdRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const sourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);

  useEffect(() => {
    if (!audioElement) return;

    // Initialize Web Audio API node only on user interaction / when available
    try {
      if (!audioContextRef.current) {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        if (AudioCtx) {
          audioContextRef.current = new AudioCtx();
        }
      }

      if (audioContextRef.current && !sourceNodeRef.current) {
        try {
          const analyser = audioContextRef.current.createAnalyser();
          analyser.fftSize = 128;
          analyser.smoothingTimeConstant = 0.8;
          const source = audioContextRef.current.createMediaElementSource(audioElement);
          source.connect(analyser);
          analyser.connect(audioContextRef.current.destination);
          analyserRef.current = analyser;
          sourceNodeRef.current = source;
        } catch (e) {
          // If already connected or CORS, fallback gracefully
          console.warn('AudioContext source connection note:', e);
        }
      }
    } catch (e) {
      console.warn('AudioContext init note:', e);
    }

    if (isPlaying && audioContextRef.current?.state === 'suspended') {
      audioContextRef.current.resume();
    }
  }, [audioElement, isPlaying]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let phase = 0;

    const render = () => {
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const barCount = 42;
      const barWidth = Math.max(2, (width / barCount) - 3);
      const dataArray = new Uint8Array(analyserRef.current?.frequencyBinCount || barCount);

      if (analyserRef.current && isPlaying) {
        analyserRef.current.getByteFrequencyData(dataArray);
      }

      phase += 0.05;

      for (let i = 0; i < barCount; i++) {
        let barHeight = 6;
        if (isPlaying) {
          if (analyserRef.current && dataArray[i % dataArray.length] > 0) {
            barHeight = Math.max(8, (dataArray[i % dataArray.length] / 255) * (height - 12));
          } else {
            // Simulated rhythmic waveform if WebAudio analyzer is silent/cross-origin
            const wave = Math.sin(phase + i * 0.28) * 0.5 + 0.5;
            barHeight = 10 + wave * (height - 24) * (0.4 + 0.6 * Math.sin((i / barCount) * Math.PI));
          }
        } else {
          // Subtle resting wave
          barHeight = 4 + Math.sin(i * 0.4) * 2;
        }

        const x = i * (barWidth + 3) + 2;
        const y = height / 2 - barHeight / 2;

        // Gradient from Ethiopian gold to emerald with warm red accent
        const gradient = ctx.createLinearGradient(0, y, 0, y + barHeight);
        const norm = i / barCount;
        if (norm < 0.35) {
          gradient.addColorStop(0, '#F59E0B'); // Warm amber gold
          gradient.addColorStop(1, '#D97706');
        } else if (norm < 0.75) {
          gradient.addColorStop(0, '#10B981'); // Emerald green
          gradient.addColorStop(1, '#059669');
        } else {
          gradient.addColorStop(0, '#EF4444'); // Ethiopian red accent
          gradient.addColorStop(1, '#B91C1C');
        }

        ctx.fillStyle = gradient;
        ctx.beginPath();
        // Rounded caps
        const radius = Math.min(barWidth / 2, barHeight / 2);
        ctx.roundRect(x, y, barWidth, barHeight, radius);
        ctx.fill();
      }

      animFrameIdRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, [isPlaying]);

  return (
    <div className="relative w-full h-16 bg-slate-900/80 rounded-xl overflow-hidden border border-slate-800/80 flex items-center justify-center px-3 py-1 shadow-inner">
      <canvas
        ref={canvasRef}
        width={500}
        height={56}
        className="w-full h-full block"
      />
    </div>
  );
};
